export default {
  apiKey: "AIzaSyCRJ63xSL1mmFQjd6oeXJr9A7viywSeHWc",
  authDomain: "racingperformance-ff6ef.firebaseapp.com",
  projectId: "racingperformance-ff6ef",
  storageBucket: "racingperformance-ff6ef.appspot.com",
  messagingSenderId: "51608199454",
  appId: "1:51608199454:web:cce8d5d46347b7a9e8e90f"
};